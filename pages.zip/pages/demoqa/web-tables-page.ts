// pages/demoqa/web-tables-page.ts
import { Page, Locator } from "@playwright/test";
import { DemoQABasePage } from "./demoqa-base-page";

export class WebTablesPage extends DemoQABasePage {
  readonly addButton: Locator;
  readonly searchBox: Locator;
  readonly table: Locator;
  readonly tableRows: Locator;
  readonly pagination: Locator;
  readonly rowsPerPageSelector: Locator;
  readonly editButtons: Locator;
  readonly deleteButtons: Locator;
  readonly registrationForm: Locator;

  constructor(page: Page) {
    super(page);
    this.addButton = page.locator("#addNewRecordButton");
    this.searchBox = page.locator("#searchBox");
    this.table = page.locator(".rt-table");
    this.tableRows = page.locator(".rt-tr-group:not(.rt-tr-group.-padRow)");
    this.pagination = page.locator(".rt-pagination");
    this.rowsPerPageSelector = page.locator(
      'select[aria-label="rows per page"]'
    );
    this.editButtons = page.locator('[title="Edit"]');
    this.deleteButtons = page.locator('[title="Delete"]');
    this.registrationForm = page.locator(".modal-content");
  }

  /**
   * Navigate to web tables page
   */
  async goto(): Promise<void> {
    await this.navigate("/webtables");
    await this.handleAds();
    await this.page.waitForSelector(".rt-table");
  }

  /**
   * Add a new record to the table
   */
  async addRecord(record: {
    firstName: string;
    lastName: string;
    email: string;
    age: string;
    salary: string;
    department: string;
  }): Promise<void> {
    await this.addButton.click();
    await this.page.waitForSelector(".modal-content");

    // Fill the registration form
    await this.page.locator("#firstName").fill(record.firstName);
    await this.page.locator("#lastName").fill(record.lastName);
    await this.page.locator("#userEmail").fill(record.email);
    await this.page.locator("#age").fill(record.age);
    await this.page.locator("#salary").fill(record.salary);
    await this.page.locator("#department").fill(record.department);

    // Submit the form
    await this.page.locator("#submit").click();

    // Wait for modal to close
    await this.page.waitForSelector(".modal-content", { state: "hidden" });
  }

  /**
   * Search for records
   */
  async searchRecords(searchText: string): Promise<void> {
    await this.searchBox.fill(searchText);
    // Wait for search results to update
    await this.page.waitForTimeout(500);
  }

  /**
   * Get all rows data
   */
  async getTableData(): Promise<string[][]> {
    const rows = await this.tableRows.all();
    const tableData: string[][] = [];

    for (const row of rows) {
      // Skip empty rows
      if ((await row.locator(".rt-td").first().textContent()) === " ") {
        continue;
      }

      const cells = await row.locator(".rt-td").all();
      const rowData: string[] = [];

      for (const cell of cells) {
        rowData.push(((await cell.textContent()) || "").trim());
      }

      if (rowData.some((text) => text !== "")) {
        tableData.push(rowData);
      }
    }

    return tableData;
  }

  /**
   * Delete a record by row index
   */
  async deleteRecord(rowIndex: number): Promise<void> {
    const deleteButtons = await this.deleteButtons.all();

    if (rowIndex < deleteButtons.length) {
      await deleteButtons[rowIndex].click();
    } else {
      throw new Error(
        `Row index ${rowIndex} is out of range. Only ${deleteButtons.length} rows available.`
      );
    }
  }

  /**
   * Edit a record by row index
   */
  async editRecord(
    rowIndex: number,
    newData: Record<string, string>
  ): Promise<void> {
    const editButtons = await this.editButtons.all();

    if (rowIndex < editButtons.length) {
      await editButtons[rowIndex].click();
      await this.page.waitForSelector(".modal-content");

      // Update fields
      for (const [field, value] of Object.entries(newData)) {
        const fieldSelector = `#${field}`;
        await this.page.locator(fieldSelector).fill(value);
      }

      // Submit changes
      await this.page.locator("#submit").click();

      // Wait for modal to close
      await this.page.waitForSelector(".modal-content", { state: "hidden" });
    } else {
      throw new Error(
        `Row index ${rowIndex} is out of range. Only ${editButtons.length} rows available.`
      );
    }
  }

  /**
   * Change rows per page
   */
  async setRowsPerPage(count: string): Promise<void> {
    await this.rowsPerPageSelector.selectOption(count);
  }
}
