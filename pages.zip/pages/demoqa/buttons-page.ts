// pages/demoqa/buttons-page.ts
import { Page, Locator } from "@playwright/test";
import { DemoQABasePage } from "./demoqa-base-page";

export class ButtonsPage extends DemoQABasePage {
  readonly doubleClickButton: Locator;
  readonly rightClickButton: Locator;
  readonly dynamicClickButton: Locator;
  readonly doubleClickMessage: Locator;
  readonly rightClickMessage: Locator;
  readonly dynamicClickMessage: Locator;

  constructor(page: Page) {
    super(page);
    this.doubleClickButton = page.locator("#doubleClickBtn");
    this.rightClickButton = page.locator("#rightClickBtn");
    this.dynamicClickButton = page.locator('button:text("Click Me")').last();
    this.doubleClickMessage = page.locator("#doubleClickMessage");
    this.rightClickMessage = page.locator("#rightClickMessage");
    this.dynamicClickMessage = page.locator("#dynamicClickMessage");
  }

  /**
   * Navigate to buttons page
   */
  async goto(): Promise<void> {
    await this.navigate("/buttons");
    await this.handleAds();
  }

  /**
   * Perform double click
   */
  async performDoubleClick(): Promise<void> {
    await this.scrollToElement(this.doubleClickButton);
    await this.doubleClickButton.dblclick();
  }

  /**
   * Perform right click
   */
  async performRightClick(): Promise<void> {
    await this.scrollToElement(this.rightClickButton);
    await this.rightClickButton.click({ button: "right" });
  }

  /**
   * Perform dynamic click
   */
  async performDynamicClick(): Promise<void> {
    await this.scrollToElement(this.dynamicClickButton);
    await this.dynamicClickButton.click();
  }

  /**
   * Get double click message
   */
  async getDoubleClickMessage(): Promise<string> {
    return await this.getText(this.doubleClickMessage);
  }

  /**
   * Get right click message
   */
  async getRightClickMessage(): Promise<string> {
    return await this.getText(this.rightClickMessage);
  }

  /**
   * Get dynamic click message
   */
  async getDynamicClickMessage(): Promise<string> {
    return await this.getText(this.dynamicClickMessage);
  }
}
