// pages/the-internet/drag-drop-page.ts
import { Page, Locator } from "@playwright/test";
import { InternetBasePage } from "./internet-base-page";

export class DragDropPage extends InternetBasePage {
  readonly columnA: Locator;
  readonly columnB: Locator;

  constructor(page: Page) {
    super(page);
    this.columnA = page.locator("#column-a");
    this.columnB = page.locator("#column-b");
  }

  async goto(): Promise<void> {
    await super.navigate("/drag_and_drop");
  }

  async dragAToB(): Promise<void> {
    const sourceBox = await this.columnA.boundingBox();
    const targetBox = await this.columnB.boundingBox();

    if (!sourceBox || !targetBox) {
      throw new Error("Unable to retrieve bounding boxes for drag and drop.");
    }

    // Move mouse to center of source element
    await this.page.mouse.move(
      sourceBox.x + sourceBox.width / 2,
      sourceBox.y + sourceBox.height / 2
    );

    // Press mouse down
    await this.page.mouse.down();

    // Move to center of target element
    await this.page.mouse.move(
      targetBox.x + targetBox.width / 2,
      targetBox.y + targetBox.height / 2
    );

    // Release mouse
    await this.page.mouse.up();

    // Optional: Add a small wait to ensure drag and drop completes
    await this.page.waitForTimeout(500);
  }

  async getColumnAText(): Promise<string> {
    return (await this.columnA.textContent()) || "";
  }

  async getColumnBText(): Promise<string> {
    return (await this.columnB.textContent()) || "";
  }
}
