// pages/the-internet/file-download-page.ts
import { Page, Locator, Download } from "@playwright/test";
import { InternetBasePage } from "./internet-base-page";

export class FileDownloadPage extends InternetBasePage {
  readonly downloadLinks: Locator;

  constructor(page: Page) {
    super(page);
    this.downloadLinks = page.locator('a[href^="download/"]');
  }

  /**
   * Navigate to file download page
   */
  async goto(): Promise<void> {
    await this.navigate("/download");
    await this.verifyPageHeader("File Downloader");
  }

  /**
   * Download a file by filename
   * @param filename The name of the file to download
   * @returns The path to the downloaded file
   */
  async downloadFile(filename: string): Promise<string> {
    // Find the link with the specified filename
    const fileLink = this.page.locator(`a:has-text("${filename}")`);

    // Wait for download to start
    const [download] = await Promise.all([
      this.page.waitForEvent("download"),
      fileLink.click(),
    ]);

    // Wait for download to complete and get the path
    const path = await download.path();

    if (!path) {
      throw new Error("Download failed");
    }

    return path;
  }

  /**
   * Get a list of all available files for download
   */
  async getAvailableFiles(): Promise<string[]> {
    const links = await this.downloadLinks.all();
    const filenames: string[] = [];

    for (const link of links) {
      const text = await link.textContent();
      if (text) {
        filenames.push(text.trim());
      }
    }

    return filenames;
  }
}
